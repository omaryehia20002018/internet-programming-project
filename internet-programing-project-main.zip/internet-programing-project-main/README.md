Please use the username *genesis* and password *librarian* for logging into the Librarian portal
Please use the username *test* and password *test* for logging into the Librarian portal

There is a bug we couldn't fix the librarian login fails the fist time but try again it will work

software needed:
XAMPP

to run the site:
1-download and unzip the file
2-copy the src file into the root directory
3-open phpmyadmin
4-create database named library_db
5-import the database in the db file
6-type in “http://localhost/src” in the browser